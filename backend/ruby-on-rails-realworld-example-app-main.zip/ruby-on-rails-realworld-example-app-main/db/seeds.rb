User.create([
  { username: "John", email: "john@email.com", password: "secret" },
  { username: "Steve", email: "steve@email.com", password: "secret" },
  { username: "Jenna", email: "jenna@email.com", password: "secret" }
])
