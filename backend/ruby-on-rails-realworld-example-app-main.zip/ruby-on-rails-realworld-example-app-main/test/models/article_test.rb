require "test_helper"

class ArticleTest < ActiveSupport::TestCase
end
