require "test_helper"

class TagTest < ActiveSupport::TestCase
end
