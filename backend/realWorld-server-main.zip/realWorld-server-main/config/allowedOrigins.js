const allowedOrigins = [
    'http://localhost:3000',
    'http://localhost:4200',
    'https://winterrrrrff.github.io',
    'https://angular-realworld-example-app-neon.vercel.app'
];

module.exports = allowedOrigins;
