"""Packages Configuration Settings."""

"""Site Packages
Although not used often, you may have to add several additional package
directories while building third party packages. Put the path of the
package here and Masonite will pick it up.

----------
@example
SITE_PACKAGES = [
   'venv/lib/python3.6/site-packages'
]
----------
"""

SITE_PACKAGES = [
    #
]
