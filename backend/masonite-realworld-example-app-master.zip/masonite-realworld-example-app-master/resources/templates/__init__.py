"""Templates directory.

This directory is responsible for storing all HTML templates for your project.
You are not required to store them here but you will need to add the environment
to the View class in a service provider if you want to use different template
environments.
"""
