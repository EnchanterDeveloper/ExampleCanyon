"""Resources directory.

This directory is responsible for storing any resource based files such as 
templates and SASS files
"""
