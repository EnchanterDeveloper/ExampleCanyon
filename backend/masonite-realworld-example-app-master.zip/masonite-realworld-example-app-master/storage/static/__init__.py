"""Static file storage directory.

This directory is responsible for storing static assets such as 
CSS, JS, public assets etc.
"""
