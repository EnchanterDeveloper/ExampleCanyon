# Udemy_bot
An automation bot for free Udemy courses for chrome,
The bot is looking for Udemy coupons from the site [udemyfreebies](https://www.udemyfreebies.com/).
The current default categories are IT and Software and Development its can be changed manually.
All the courses by default are obviously free, are over 4.2 stars, and rated by more the 200 people can be changed manually as well.

__Note that you will need to have up to date chrome web driver__

## Install Requirements
```
pip install -r requirements.txt
```

## Usage 
  
```
Edit categories_list to your liking in Udemy_bot.py

python Udemy_bot.py EMAIL PASSWORD
```
