import Code from '@components/code-block'

export default {
  code: Code,
}
