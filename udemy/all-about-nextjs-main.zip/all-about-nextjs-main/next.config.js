module.exports = {
  images: {
    domains: ['i.ytimg.com'],
  },
}
