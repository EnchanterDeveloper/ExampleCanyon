# Naruto-game
This is a naruto game. In this you have 3 characters naruto, sasuke and sakura. And the enemies are Obito, pain and madara.
Naruto, sasuke, sakura take their turn to attack choosen enemies. naruto and others can use any attacks magic spells. naruto and others can heal themselves too. also they can heal all of them using a single spell in one go.
As naruto and others enemies madara,pain can heal themselves too. This is fun to play also i had a lot of fun while making of this.

## The starting screen looks like this 
![Image](https://github.com/Sanket758/Naruto-game/blob/master/Screenshots/Screenshot%20from%202020-01-21%2021-54-10.png "Naruto Game")

## You choose various magic spells like...
![Image](https://github.com/Sanket758/Naruto-game/blob/master/Screenshots/Screenshot%20from%202020-01-21%2021-54-36.png "Naruto Game")

## You can also choose to heal or use other items like...
![Image](https://github.com/Sanket758/Naruto-game/blob/master/Screenshots/Screenshot%20from%202020-01-21%2021-54-55.png "Naruto Game")
