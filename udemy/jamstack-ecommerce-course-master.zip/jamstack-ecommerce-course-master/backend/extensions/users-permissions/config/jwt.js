module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'a01c893a-1b6d-4813-a804-cbdeb9a42a63'
};