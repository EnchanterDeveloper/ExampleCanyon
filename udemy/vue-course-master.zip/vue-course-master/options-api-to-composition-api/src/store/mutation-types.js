export const ADD_TASK = "ADD_TASK";
export const REMOVE_TASK = "REMOVE_TASK";
export const UPDATE_TASK = "UPDATE_TASK";
export const SET_ONLY_PENDING = "SET_ONLY_PENDING";
export const SET_ACTIVE_PROJECT = "SET_ACTIVE_PROJECT";
