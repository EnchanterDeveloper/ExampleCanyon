import { createApp } from "vue";
import Landing from "./Landing.vue";

createApp(Landing).mount("#app");
