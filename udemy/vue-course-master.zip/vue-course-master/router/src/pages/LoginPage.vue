<template>
  <h3>Login</h3>
  <div>The login form goes here...</div>
</template>