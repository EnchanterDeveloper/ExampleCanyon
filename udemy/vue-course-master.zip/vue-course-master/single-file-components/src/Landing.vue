<template>
  <div class="flex h-screen">
    <div class="m-auto">
      <div class="text-center">
        <h3 class="text-3xl mb-2">Landing Page of Todo App!</h3>
        <a href="/" class="underline">Go to the app!</a>
      </div>
    </div>
  </div>
</template>