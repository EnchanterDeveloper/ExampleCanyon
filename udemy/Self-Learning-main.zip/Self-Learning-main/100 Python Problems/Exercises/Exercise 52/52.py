#Please fix the script so that it returns the user submited first name for the first %s
#and the second name for the second %s

firstname = input("Enter first name: ")
secondname = input("Enter second name: ")
print("Your first name is %s and your second name is %s" % firstname, secondname)
