#Create a dictionary of two keys, a and b and two values 1 and 2 for keys a and b respectively.
d = {"a": 1, "b": 2}
