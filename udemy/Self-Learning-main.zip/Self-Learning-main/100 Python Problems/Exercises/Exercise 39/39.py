#The script is supposed to print out the cosine of 90
import math
print(math.cosine(1))
