#Create a script that converts all items of the range to strings
my_range = range(1, 21)
print(map(str, my_range))
for i in map:
    print(i)
