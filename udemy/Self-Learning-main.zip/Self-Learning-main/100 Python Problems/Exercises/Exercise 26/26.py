#Make a script that prints out numbers from 1 to 10

for i in range(1,11):
    print(i)
