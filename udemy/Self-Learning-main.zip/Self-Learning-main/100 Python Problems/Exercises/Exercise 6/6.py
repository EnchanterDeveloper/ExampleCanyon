#Complete the script so that it prints out a list containing letters d, e, f.
letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]
print(letters[3:6])
