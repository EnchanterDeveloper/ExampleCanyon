#What will this script produce?
#A: 3
a = 1
a = 2
a = 3
print(a)
