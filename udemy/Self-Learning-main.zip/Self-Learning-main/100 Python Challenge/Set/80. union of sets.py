"""
Write a Python program to find the union of two sets.

set1 = {1,2,3,4,5}

set2 = {4,5,6,7,8}
"""

def set_union(set1,set2):
    return (set1 | set2)
    