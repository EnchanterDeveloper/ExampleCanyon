"""
Write a function to find all the elements that are present in set1 but not in set2.

set1 = {1,2,3,4,5}

set2 = {4,5,6,7,8}
"""

def set_diff(set1, set2):
    return set1.difference(set2)
    