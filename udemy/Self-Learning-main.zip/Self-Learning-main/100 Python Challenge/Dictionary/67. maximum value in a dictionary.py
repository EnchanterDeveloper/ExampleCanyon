"""
Write a Python function that returns the maximum value in a dictionary.

input_dict = {1:1, 2:4, 3:9, 4:16, 5:25}

"""

#Solution is:

def max_value(input_dict):
    return max(input_dict.values())

        
        
