"""
Write a function that accepts a string with decimals and converts it to an integer.

Example:

input_string = '12.34'

Expected output = 12
"""

def str_to_int(input_string):
    
    input_string= int(float(input_string))
    
    return input_string
    
