"""
Write a function that removes white spaces from an input string.

Example:

input_string = 'C h a l l e n g e s'

Expected output ='Challenges'
"""

def remove_spaces(input_string):
    output_string = input_string.replace(" ", "")
    return output_string
    
