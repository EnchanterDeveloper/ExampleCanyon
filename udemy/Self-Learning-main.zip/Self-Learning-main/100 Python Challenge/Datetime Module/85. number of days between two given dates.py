"""
Write a function that calculates the number of days between two given dates.

Input Data:

Date1 = 2011-1-1

Date2 = 2021-1-1'
"""

import datetime
def date_diff(Date1, Date2):
    delta = Date2 - Date1
    return (delta)