"""
1. Write a function that accepts a number and returns its square root. The output can be rounded
to 3 decimal places.
"""


def sqrt(num):
    k = num ** 0.5
    return (round(k, 3))
    