"""
Write a function to find the power of any number x ^ y.
"""



def power(x,y):
    return (x ** y)