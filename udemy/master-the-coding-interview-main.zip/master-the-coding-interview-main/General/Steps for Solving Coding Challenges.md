# Steps for Solving Coding Challenges
## Intro
1. Verify Constraints
2. Create Testcases
## Brute Force + Optimal
1. Brainstorming & Pattern Observations
2. Pseudocode 
3. Code
4. Run testcases against code
5. Analyze time + space complexity

