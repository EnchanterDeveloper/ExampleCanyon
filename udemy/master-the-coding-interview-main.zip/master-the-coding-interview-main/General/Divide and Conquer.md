# Divide and Conquer
## General Steps
1. Multi-branched recursion (splits the data into multiple parts)
2. Breaks problem into multiple sub-problems
3. Combines solutions of sub problems into the solution for original problem