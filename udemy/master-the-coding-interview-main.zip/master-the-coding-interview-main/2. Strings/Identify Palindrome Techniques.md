## Identify Palindrome Techniques: 
1. Initialize left and right pointers at first and last index and traverse inwards until center to see if chars match
2. Initialize left and right pointers at center and traverse outwards to see if chars match
3. Flip given string and check if it matches given string