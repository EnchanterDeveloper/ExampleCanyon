INSERT INTO
    `user` (
        `id`,
        `username`,
        `password`,
        `email`,
        `firstName`,
        `lastName`,
        `profileId`
    )
VALUES
    (
        NULL,
        'e2e-test',
        '$2b$10$5v5ZIVbPGXf0126yUiiys.z/POxSaus.iSbzXj7cTRW9KWGy5bfcq',
        'e2e@test.com',
        'End',
        'To End',
        NULL
    )