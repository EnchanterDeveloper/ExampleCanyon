export { NextJSCourseLayout } from "./NextJSCourseLayout";
