export default function About() {
  return (
    <div>
      <h1>Description of my awesome GitHub cards app!</h1>
    </div>
  );
}
