import TodoApp from "../components/TodoApp";

export default function Index() {
  return <TodoApp />;
}
