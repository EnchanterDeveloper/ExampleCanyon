# React + Next JS with TypeScript

This repo contains the complementary material for [React + Next JS with TypeScript](https://www.udemy.com/course/react-and-next-js-with-typescript/?referralCode=7202184A1E57C3DCA8B2) course.

Please enroll into the course for more information.

![Sricky Section Header](https://github.com/mayank1513/sticky-section-header/blob/master/sticky-section-header.gif?raw=true)
