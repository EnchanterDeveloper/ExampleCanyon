import * as React from 'react'

function LazyComponent() {
  return <div>I am lazy!</div>
}

export default LazyComponent
