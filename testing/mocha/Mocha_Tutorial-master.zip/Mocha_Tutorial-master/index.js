function sayHello() {
	return "hello";
}

function calculateSum(a,b) {
	return a+b;
}

function Multiply(a,b) {
	return a*b;
}


module.exports = {
	sayHello : sayHello,
	calculateSum : calculateSum ,
	Multiply: Multiply
}