import IArticle from "./IArticle";
export default interface IArticleList {
  articles: IArticle[];
  articlesCount: number;
}
