export default interface IArticleAddCommentRequestParams {
  body: string;
}
