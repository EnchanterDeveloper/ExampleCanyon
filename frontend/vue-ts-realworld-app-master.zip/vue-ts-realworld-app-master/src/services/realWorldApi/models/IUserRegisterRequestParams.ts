export default interface IUserRegisterRequestParams {
  email: string;
  password: string;
  username: string;
}
