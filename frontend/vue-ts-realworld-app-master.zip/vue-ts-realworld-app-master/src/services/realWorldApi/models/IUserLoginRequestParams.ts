export default interface IUserLoginRequestParams {
  email: string;
  password: string;
}
