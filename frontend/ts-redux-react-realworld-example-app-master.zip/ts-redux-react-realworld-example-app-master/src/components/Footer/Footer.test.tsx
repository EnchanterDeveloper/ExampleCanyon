import { render } from '@testing-library/react';
import { Footer } from './Footer';

it('Should render', () => {
  render(<Footer />);
});
