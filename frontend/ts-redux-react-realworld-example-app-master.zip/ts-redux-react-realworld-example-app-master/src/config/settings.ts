export default {
  baseApiUrl: 'https://api.realworld.io/api/',
};
