export interface TagList {
  tags: string[];
}
