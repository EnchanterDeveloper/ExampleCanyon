export const STORAGE_KEY = {
  user: 'userInfo',
} as const;
