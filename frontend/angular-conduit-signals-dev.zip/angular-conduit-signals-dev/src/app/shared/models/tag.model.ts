export interface TagAPIResponse {
  tags: string[];
}
