export interface ErrorResponse {
  errors: Record<string, string[]>;
}
