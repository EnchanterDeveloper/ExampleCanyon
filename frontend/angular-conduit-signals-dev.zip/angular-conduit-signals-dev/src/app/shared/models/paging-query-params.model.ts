export interface PagingQueryParams {
  limit: number;
  offset: number;
}
