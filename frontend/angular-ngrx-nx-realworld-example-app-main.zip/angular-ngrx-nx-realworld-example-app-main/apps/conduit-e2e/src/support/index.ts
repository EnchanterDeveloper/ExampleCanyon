import './commands';

beforeEach(() => {
  cy.clearLocalStorage();
});
