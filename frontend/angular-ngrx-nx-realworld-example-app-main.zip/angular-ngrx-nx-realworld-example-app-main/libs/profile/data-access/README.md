# profile-data-access

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test profile-data-access` to execute the unit tests.
