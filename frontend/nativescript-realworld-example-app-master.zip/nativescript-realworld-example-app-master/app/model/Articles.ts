import { Article } from "~/model/Article";

/**
 *
 */
export class Articles {
    /** */
    public articles: Article[] = [];
    /** */
    public articlesCount: number = 0;
}
