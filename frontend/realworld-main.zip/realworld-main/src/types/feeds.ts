export const enum FeedType {
  Your,
  Global,
  Tag,
  Profile,
  Favorite,
}
