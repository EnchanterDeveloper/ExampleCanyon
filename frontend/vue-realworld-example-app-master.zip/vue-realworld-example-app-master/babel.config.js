module.exports = {
  env: {
    dev: {
      presets: ["@vue/cli-plugin-babel/preset"]
    },
    test: {
      presets: ["@babel/preset-env"]
    }
  }
};
