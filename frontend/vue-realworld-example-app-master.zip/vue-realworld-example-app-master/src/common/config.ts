export const API_URL = "https://api.realworld.io/api";
export default API_URL;
