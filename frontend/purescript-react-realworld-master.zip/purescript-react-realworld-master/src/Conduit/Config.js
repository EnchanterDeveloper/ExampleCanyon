export const apiEndpoint = process.env.API_ENDPOINT || "";

export const nodeEnv = process.env.NODE_ENV || "";
