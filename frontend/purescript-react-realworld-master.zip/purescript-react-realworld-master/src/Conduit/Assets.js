export { default as smileyCyrus } from "../../assets/smiley-cyrus.jpg";
