import { main } from "./output/Main";

main();
