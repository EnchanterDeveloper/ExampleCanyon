import {registerRootComponent} from 'expo';

import App from './src/app';

registerRootComponent(App);
