export {default} from './CreateArticle';
