export default {
  articles: 'Articles',
  article: 'Article',
  userArticles: 'UserArticle',
  profile: 'Profile',
  authModal: 'AuthModal',
  settingsModal: 'SettingsModal',
  createArticleModal: 'CreateArticleModal',
};
