declare module 'wix-react-native-ui-lib';
declare module 'superagent-promise';
